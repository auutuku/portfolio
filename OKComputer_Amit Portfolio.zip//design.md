# Design System - Amit Uutukuru Portfolio

## Visual Language

### Color Palette
- **Background**: #0B0B0C (near-black)
- **Surfaces**: #121315
- **Text Primary**: #F2F3F5
- **Text Muted**: #A7ABB3
- **Accent Gradient**: from #6EE7F9 to #A78BFA (cyan→violet)
- **CTA Accent**: #22D3EE

### Typography
- **Font**: Inter (system fallback)
- **Scale**: sm/base/lg/xl/2xl/4xl/6xl
- **Headings**: Tight letter-spacing, bold weights
- **Body**: Comfortable line-height, regular weight

### Layout & Grid
- **Container**: Max-width with centered content
- **Grid**: CSS Grid and Flexbox for responsive layouts
- **Spacing**: Consistent 8px base unit system
- **Corners**: rounded-2xl for modern feel
- **Shadows**: Soft, layered shadows for depth

## Visual Effects

### Background Effects
- Subtle animated gradient behind hero name
- Particle system using p5.js for ambient movement
- Consistent dark theme throughout

### Animation Library Usage
- **Anime.js**: Smooth transitions and micro-interactions
- **IntersectionObserver**: Scroll-triggered animations
- **CSS transforms**: Hardware-accelerated hover effects

### Hover Effects
- Cards: 3D tilt with shadow expansion
- Buttons: Glow and scale effects
- Links: Animated underlines
- Images: Subtle zoom with overlay reveal

### Interactive Elements
- Navigation: Active state with gradient underline
- Project cards: Modal trigger with preview
- Contact buttons: Ripple effect on click
- Form inputs: Floating labels with focus states

## Component Styling

### Navigation
- Sticky header with backdrop blur
- Gradient active indicators
- Smooth scroll behavior
- Mobile-responsive hamburger menu

### Project Cards
- Rounded corners with soft shadows
- Hover lift effect
- Tag chips with gradient backgrounds
- Modal trigger indicators

### Buttons
- Primary: Gradient background with hover glow
- Secondary: Outline with hover fill
- Ghost: Text-only with underline animation
- Consistent padding and typography

### Modals
- Backdrop blur with fade-in
- Centered content with max-width
- Close button with hover rotation
- Smooth slide-up animation