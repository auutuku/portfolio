# Interaction Design - Amit Uutukuru Portfolio

## Core Interactions

### 1. Scroll-Spy Navigation
- Sticky top navigation with smooth scrolling to sections
- Active state highlighting based on current viewport section
- Keyboard accessible with visible focus rings
- Uses IntersectionObserver for performance

### 2. Project Modals
- Click on project cards opens detailed modal with:
  - Image carousel (placeholder SVGs)
  - Problem → Approach → Result structure
  - External links to case studies/prototypes
- Close with ESC key or click outside
- Smooth fade-in/out transitions

### 3. Copy Link Tooltips
- Each project card has "Copy Link" button
- Shows "Copied!" tooltip on click
- Clipboard API integration
- Auto-hide tooltip after 2 seconds

### 4. Hover Effects
- Project cards: lift with translate-y-1 and shadow-xl
- Buttons: subtle scale and glow effects
- Links: underline animation
- Respects prefers-reduced-motion

### 5. Mobile Email CTA
- Floating bottom-right email button on mobile
- Fixed position with backdrop blur
- Smooth slide-in animation

## Accessibility Features
- ARIA labels for all interactive elements
- Keyboard navigation support
- Focus indicators meeting WCAG 2.1 AA
- Screen reader friendly modal announcements
- Reduced motion preferences respected

## Performance Optimizations
- IntersectionObserver for scroll animations
- Lazy loading for modal images
- Minimal JavaScript footprint
- CSS transforms for smooth animations